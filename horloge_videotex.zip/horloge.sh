#!/bin/bash
heureminitel=050000
heuresysteme=$(date +%H%M%S)
#force le parametrage du port serie /dev/ttyUSB0 pour un minitel 1 a 1200 bauds
stty -F /dev/ttyUSB0 1200 istrip cs7 parenb -parodd brkint ignpar icrnl ixon ixany opost onlcr cread hupcl isig icanon echo echoe echok
#initialisation de l'ecran et affichage initial de l'horloge
cd videotex
cat erase.vdt > /dev/ttyUSB0
#comparaison digit par digit entre l'heure affichee et l'heure systeme
while :
do
for ((i=1;i<=4;i=i+2))
	do
	#si l'un des deux digits (heure ou minute) a change, on reaffiche tout le bloc
	if [ ${heureminitel:$i-1:1} != ${heuresysteme:$i-1:1} ] || [ ${heureminitel:$i:1} != ${heuresysteme:$i:1} ]
	then
		paste h$i.vdt ${heuresysteme:$i-1:1}.vdt > /dev/ttyUSB0
		paste h$[i+1].vdt ${heuresysteme:$i:1}.vdt > /dev/ttyUSB0
	fi
	cat separateur.vdt > /dev/ttyUSB0
	done
heureminitel=$heuresysteme
heuresysteme=$(date +%H%M%S)
done
